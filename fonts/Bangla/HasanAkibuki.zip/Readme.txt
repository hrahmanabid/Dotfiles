----------------------------------------------------------------------------------------------------------------------------------------------------------------
বাংলা গাইডলাইন (BN)
----------------------------------------------------------------------------------------------------------------------------------------------------------------
প্রথমেই আমাদের ফ্রি ফন্ট ডাউনলোড ও ব্যবহার করার জন্য আপনাকে জানাই অসংখ্য ধন্যবাদ।

	***** আমাদের ফন্ট ব্যবহারে আপনার কোনো ধরণের সমস্যা হলে, টিউটোরিয়ালের সাহায্য নিতে ভিজিট করুন- https://youtube.com/lipighor
	***** আপনার মূল্যবান মতামত ও সাজেশন আমাদের ফেসবুক পেজে জানান- https://facebook.com/lipighor

এন্ড ইউজার লাইসেন্স এগ্রিমেন্ট
আপনি যদি আমাদের ফ্রি ফন্ট/ ফন্টসমূহ ব্যবহার করতে চান, তবে অবশ্যই আপনাকে নিম্নোক্ত বিধিনিষেধসমূহ সতর্কভাবে মেনে চলতে হবে-

	১. আপনাকে লিপিঘর ফ্রি ফন্ট/ ফন্টসমূহ বিনামূল্যে ব্যবহার করার সুযোগ দিচ্ছে মাত্র, ফন্টের মালিকানা বা কপিরাইট আপনার হাতে তুলে দিচ্ছে না।
	২. আপনি লিপিঘর থেকে ডাউনলোডকৃত ফ্রি ফন্ট/ ফন্টসমূহের zip/ttf ফাইল কোনোভাবেই অন্য ওয়েবসাইট/ সোশ্যাল মিডিয়া/ ই-মেল/ সিডি/ ডিভিডি সহ অন্য যে কোনো মাধ্যমে বিতরণ/ বিক্রয়/ আপলোড/ রি-আপলোড/ অন্য কোন ফন্টের সাথে বিনিময় করতে পারবেন না।
	৩. আপনি লিপিঘর থেকে ডাউনলোডকৃত  ফ্রি ফন্ট/ ফন্টসমূহের নাম বদল করে অথবা শেপ মোডিফাই করে নিজস্ব সম্পদ/ মেধাসম্পত্তি দাবী করতে পারবেন না।
	৪. আপনি লিপিঘরের ফ্রি ফন্ট/ ফন্টসমূহ ব্যবহার করে সমস্ত রকম ডিজাইন (কমার্শিয়াল ও নন- কমার্শিয়াল) তৈরি করতে পারবেন, এবং সেই ডিজাইনগুলিকে সমস্ত সোশ্যাল মিডিয়া নেটওয়ার্কে শেয়ার বা বিক্রয় করতে পারবেন।
	৫. আপনি লিপিঘরের ফ্রি ফন্ট/ ফন্টসমূহ কমার্শিয়াল ডিজাইনের কাজে ব্যবহার করলে লিপিঘরকে ক্রেডিট (ফন্ট কৃতজ্ঞতা- lipighor.com) দিতে পারেন (ঐচ্ছিক)। 
	৬. লিপিঘরের ফ্রি ফন্ট আপনি আপনার ওয়েবসাইটে ওয়েবফন্ট হিসাবে ব্যবহার করতে পারেন, তবে সেক্ষেত্রে অবশ্যই আপনাকে ই-মেলের মাধ্যমে (admin@lipighor.com) অনুমতি নিতে হবে এবং ল্যান্ডিং পেজের ফুটারে লিপিঘরের ব্যাকলিংক  (ওয়েবফন্ট- lipighor.com) প্রদান করতে হবে।	
	
	*** যদি আপনি লিপিঘরের ফ্রি ফন্ট/ ফন্টসমূহ কারো কাছ থেকে অর্থ বা অন্য কোন কিছুর বিনিময়ে ক্রয় করে থাকেন, তবে সেই প্রতারকের সমস্ত তথ্যসমূহ আমাদের সাথে শেয়ার করুন, আমরা তার বিরুদ্ধে আইনি পদক্ষেপ গ্রহণ করবো।
	*** যদি আপনি আপনার তৈরি/ ডিজাইনকৃত ফন্ট লিপিঘর থেকে প্রকাশ করতে চান, তবে আমাদের ফেসবুক পেজে বা আমাদের ই-মেল করুন- admin@lipighor.com
	*** আপনাদেরকে প্রতিনিয়ত নিত্য নতুন ফ্রি ফন্ট উপহার দেবার কাজে আমাদের আগ্রহপ্রদান করতে, আপনার সামর্থ্য অনুযায়ী দান করুন - https://lipighor.com/donation.html
	*** লিপিঘরের লাইসেন্স ইনফর্মেশন বিস্তারিত জানতে ভিজিট করুন - https://lipighor.com/condition.html
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------
English Guideline (EN)
----------------------------------------------------------------------------------------------------------------------------------------------------------------

At first, thank you for downloading and using our free font.

	***** If you are facing any difficulties using our fonts, Please follow our Tutorial from- https://youtube.com/lipighor
	***** Leave your valuable Questions/ Suggestions/ Opinion here- https://facebook.com/lipighor

End User License Agreement
If you want to use our Free Fonts, you have to to follow the rules strictly-

	1. Lipighor is only giving you the license to use free fonts without any cost/price, Not giving you the ownership/ copyright. 
	2. You cannot distribute/ sell/ upload/re-upload/ share the font files (i.e.- zip/ttf etc.) downloaded from Lipighor, in any condition, in any other website/social media/ CD/ DVD/ e-mail or another medium.
	3. You cannot change the name/ modify shapes of any font downloaded from lipighor and claim them as your own intellectual property.
	4. You can use the fonts downloaded from lipighor in all your designs (Non-commercial or commercial) & share/ sell these designs freely.
	5. If you use our fonts in commercial design, you can give credit (Font Credit- lipighor.com) to Lipighor in your design showcase. (Optional)
	6. If you want to use our free fonts as your web font, you have to take permission via e-mail (admin@lipighor.com) and give backlink (Web font- lipighor.com) in footer area of your landing page.

	*** If You've purchased this free font from anyone, share his/her contact details with us, we will take legal step against the fraud.
	*** If you're interested in Creating your own font, please contact us- admin@lipighor.com
	*** If You want us to survive and continuing Provide you with free fonts, please encourage us by donating - https://lipighor.com/donation.html
	*** To know our licensing terms & conditions in details, please visit - https://lipighor.com/condition.html
